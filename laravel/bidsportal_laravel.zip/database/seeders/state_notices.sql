INSERT INTO `state_notices` (`state_notice_id`, `notice_name`, `sort`, `background_color`) VALUES
(11, 'Request for Proposal', 8, 'black'),
(13, 'Request for Information', 9, 'blue'),
(16, 'Award Notice', 6, 'grey');