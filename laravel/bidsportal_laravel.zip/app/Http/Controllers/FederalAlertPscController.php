<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class FederalAlertPscController extends Controller
{
    //
}
