<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class InternationalAttachmentController extends Controller
{
    //
}
