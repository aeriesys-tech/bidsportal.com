<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class StateContactsController extends Controller
{
    //
}
