<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PrivateContactController extends Controller
{
    //
}
