<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class FederalOfficeAddressController extends Controller
{
    //
}
