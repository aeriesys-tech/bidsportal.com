<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class FederalAlertStateController extends Controller
{
    //
}
