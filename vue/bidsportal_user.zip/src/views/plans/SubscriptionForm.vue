<template>
    <section class="pt-4">
        <div class="container">
            <div class="row justify-content-center">
                <p class="text-center">We would be very happy to add your logo to the list of our clients. Please fill a short form below to continue</p>

                <!-- Main content START -->
                <div class="col-lg-8 col-xl-9">
                    <div class="vstack gap-4">
                        <!-- Personal info START -->
                        <div class="card border">
                            <!-- Card body START -->
                            <div class="card-body">
                                <!-- Form START -->
                                <form class="row g-3">
                                    <!-- Name -->
                                    <div class="col-md-6">
                                        <label class="form-label">Price</label>
                                        <input type="text" class="form-control" placeholder="Price" />
                                    </div>

                                    <!-- Email -->
                                    <div class="col-md-6">
                                        <label class="form-label">Month</label>
                                        <input type="text" class="form-control" placeholder="Month" />
                                    </div>

                                    <!-- Mobile -->
                                    <div class="col-md-12">
                                        <label class="form-label">Discount Amount %</label>
                                        <input type="text" class="form-control" placeholder="Discount Amount %" />
                                    </div>

                                    <!-- Nationality -->
                                    <div class="col-md-12">
                                        <label class="form-label">Total Amount Paid<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" placeholder="Total Amount Paid" />
                                    </div>

                                    <!-- Button -->
                                    <div class="col-12 text-center">
                                        <a href="#" class="btn btn-sm btn-primary mb-0">Pay</a>
                                    </div>
                                </form>
                                <!-- Form END -->
                            </div>
                            <!-- Card body END -->
                        </div>
                        <!-- Personal info END -->
                    </div>
                </div>
                <!-- Main content END -->
            </div>
        </div>
    </section>
</template>
