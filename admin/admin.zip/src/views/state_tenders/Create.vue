<template>
    <div class="container-fluid pb-3">
        <div class="d-flex justify-content-between">
            <h2 class="main-title mb-3">New State Tender</h2>
        </div>
        <div class="row g-3">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="d-sm-flex align-items-center justify-content-between">
                            <h6 class="card-title mb-0"><strong>Add State Bid</strong></h6>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-sm-4">
                                <div class="form-group">
                                    <label>Region <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control form-control-sm" :class="{ 'is-invalid': errors.region }" v-model="tender.region" />
                                    <span v-if="errors.region" class="invalid-feedback">{{ errors.region[0] }}</span>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="form-group">
                                    <label>Country <span class="text-danger">*</span></label>
                                    <search :class="{ 'is-invalid': tender.errors?.country_id }"
                                        :customClass="{ 'is-invalid': tender.errors?.country_id }" :initialize="tender.country_id" id="country_id"
                                        label="country_name" placeholder="Select Country" :data="countries" @input="country => handleCountryChange(country)">
                                    </search>
                                    <span v-if="errors.country_id" class="invalid-feedback">{{ errors.country_id[0] }}</span>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="form-group">
                                    <label>State / Location Issued <span class="text-danger">*</span></label>
                                    <search :class="{ 'is-invalid': tender.errors?.state_id }"
                                        :customClass="{ 'is-invalid': tender.errors?.state_id }" :initialize="tender.state_id" id="state_id"
                                        label="state_name" placeholder="Select State" :data="states" @input=" country => tender.state_id = country">
                                    </search>
                                </div>
                            </div>
                            <div class="col-sm-4 margin_top">
                                <div class="form-group">
                                    <label>Bid / RFP Number <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control form-control-sm" :class="{ 'is-invalid': errors.tender_no }" v-model="tender.tender_no" />
                                    <span v-if="errors.tender_no" class="invalid-feedback">{{ errors.tender_no[0] }}</span>
                                </div>
                            </div>
                            <div class="col-sm-4 margin_top">
                                <div class="form-group">
                                    <label>Bid Title <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control form-control-sm" :class="{ 'is-invalid': errors.title }" v-model="tender.title" />
                                    <span v-if="errors.title" class="invalid-feedback">{{ errors.title[0] }}</span>
                                </div>
                            </div>
                            <div class="col-sm-4 margin_top">
                                <div class="form-group">
                                    <label>Issuing Agency <span class="text-danger">*</span></label>
                                    <search :class="{ 'is-invalid': tender.errors?.state_agency_id }"
                                        :customClass="{ 'is-invalid': tender.errors?.state_agency_id }" :initialize="tender.state_agency_id" id="agency_id"
                                        label="state_agency_name" placeholder="Select Agency" :data="agencies" @input=" agency => tender.state_agency_id = agency" @updateAgencies="updateAgencies">
                                    </search>
                                    <span class="invalid-feedback" v-if="tender.errors?.state_agency_id?.length">{{ tender.errors?.state_agency_id[0] }}</span>
                                </div>
                            </div>
                            <div class="col-sm-4 margin_top">
                                <div class="form-group">
                                    <label>Notice <span class="text-danger">*</span></label>
                                    <select class="form-control form-control-sm" :class="{'is-invalid' : tender.errors?.state_notice_id }">
                                        <option value="null">Select Notice</option>
                                        <option v-for="notice, notice_key in notices" :key="notice_key" :value="notice.state_notice_id">{{ notice.notice_name }}</option>
                                    </select>
                                    <span class="invalid-feedback" v-if="tender.errors?.state_notice_id?.length">{{ tender.errors?.state_notice_id[0] }}</span>
                                </div>
                            </div>
                            <div class="col-sm-4 margin_top">
                                <div class="form-group">
                                    <label>Posted Date <span class="text-danger">*</span></label>
                                    <input type="date" class="form-control form-control-sm" :class="{ 'is-invalid': errors.posted_date }" v-model="tender.posted_date" />
                                    <span v-if="errors.posted_date" class="invalid-feedback">{{ errors.region[0] }}</span>
                                </div>
                            </div>
                            <div class="col-sm-4 margin_top">
                                <div class="form-group">
                                    <label>Due Date <span class="text-danger">*</span></label>
                                    <input type="date" class="form-control form-control-sm" :class="{ 'is-invalid': errors.expiry_date }" v-model="tender.expiry_date" />
                                    <span v-if="errors.expiry_date" class="invalid-feedback">{{ errors.expiry_date[0] }}</span>
                                </div>
                            </div>
                            <div class="col-sm-4 margin_top">
                                <div class="form-group">
                                    <label>Place of Performance - City <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control form-control-sm" :class="{ 'is-invalid': errors.city_name }" v-model="tender.city_name" />
                                    <span v-if="errors.city_name" class="invalid-feedback">{{ errors.city_name[0] }}</span>
                                </div>
                            </div>
                            <div class="col-sm-4 margin_top">
                                <div class="form-group">
                                    <label>State <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control form-control-sm" :class="{ 'is-invalid': errors.state_name }" v-model="tender.state_name" />
                                    <span v-if="errors.state_name" class="invalid-feedback">{{ errors.state_name[0] }}</span>
                                </div>
                            </div>
                            <div class="col-sm-4 margin_top">
                                <div class="form-group">
                                    <label>Country <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control form-control-sm" :class="{ 'is-invalid': errors.country_name }" v-model="tender.country_name" />
                                    <span v-if="errors.country_name" class="invalid-feedback">{{ errors.country_name[0] }}</span>
                                </div>
                            </div>
                            <div class="col-sm-4 margin_top">
                                <div class="form-group">
                                    <label>Contracting Office Address - City <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control form-control-sm" :class="{ 'is-invalid': errors.city }" v-model="tender.city" />
                                    <span v-if="errors.city" class="invalid-feedback">{{ errors.city[0] }}</span>
                                </div>
                            </div>
                            <div class="col-sm-4 margin_top">
                                <div class="form-group">
                                    <label>State <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control form-control-sm" :class="{ 'is-invalid': errors.state }" v-model="tender.state" />
                                    <span v-if="errors.state" class="invalid-feedback">{{ errors.state[0] }}</span>
                                </div>
                            </div>
                            <div class="col-sm-4 margin_top">
                                <div class="form-group">
                                    <label>Country <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control form-control-sm" :class="{ 'is-invalid': errors.country }" v-model="tender.country" />
                                    <span v-if="errors.country" class="invalid-feedback">{{ errors.country[0] }}</span>
                                </div>
                            </div>
                            <div class="col-sm-4 margin_top">
                                <div class="form-group">
                                    <label>Bid Posting Link <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control form-control-sm" :class="{ 'is-invalid': errors.tender_url }" v-model="tender.tender_url" />
                                    <span v-if="errors.tender_url" class="invalid-feedback">{{ errors.tender_url[0] }}</span>
                                </div>
                            </div>
                            <div class="col-sm-4 margin_top">
                                <div class="form-group">
                                    <label>Single Download Fee <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control form-control-sm" :class="{ 'is-invalid': errors.fees }" v-model="tender.fees" />
                                    <span v-if="errors.fees" class="invalid-feedback">{{ errors.fees[0] }}</span>
                                </div>
                            </div>
                            <div class="col-sm-4 margin_top">
                                <div class="form-group">
                                    <label>Category <span class="text-danger">*</span></label>
                                    <search :class="{ 'is-invalid': tender.errors?.category_id }"
                                        :customClass="{ 'is-invalid': tender.errors?.category_id }" :initialize="tender.category_id" id="category_id"
                                        label="category_name" placeholder="Select Category" :data="categories" @input=" category => tender.category_id = category">
                                    </search>
                                    <span class="invalid-feedback" v-if="tender.errors?.category_id?.length">{{ tender.errors?.category_id[0] }}</span>
                                </div>
                            </div>
                            <div class="col-sm-12 margin_top">
                                <div class="form-group">
                                    <label>Category <span class="text-danger">*</span></label>
                                   
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer">
                        <div class="d-flex justify-content-between align-items-center">
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    import search from "@/components/Search.vue";
    export default {
        components: {
            // Pagination, 
            search
        },
        
        data() {
            return {
                tender:{
                    region : '',
                    country_id :'',
                    state_id : '',
                    tender_no : '',
                    title : '',
                    state_agency_id : '',
                    state_notice_id : '',
                    posted_date : '',
                    due_date : '',
                    place_of_performace: {
                        city_name : '',
                        state_name : '',
                        country_name : ''
                    },
                    contracting_office_address : {
                        city : '',
                        state : '',
                        country : ''
                    }
                },
                countries:[],
                states:[],
                notices:[],
                categories:[],
                agencies:[],
                errors:[]
            };
        },
        mounted() {
            this.getCountries() 
        },

        methods: {
            handleCountryChange(country) {
                this.tender.country_id = country
                if(typeof this.tender.country_id === 'number'){
                    this.getStates()
                }
            },                        
            getCountries() {
                let vm = this;
                let loader = vm.$loading.show();
                vm.$store
                    .dispatch("post", { uri: "getCountries" })
                    .then((response) => {
                        loader.hide();
                        vm.countries = response.data
                        vm.getStateNotices()
                    })
                    .catch(function (error) {
                        loader.hide();
                        vm.errors = error.response.data.errors;
                        vm.$store.dispatch("error", error.response.data.message);
                    });
            },

            getStates() {
                let vm = this;
                let loader = vm.$loading.show();
                vm.$store
                    .dispatch("post", { uri: "getStates", data:vm.tender })
                    .then((response) => {
                        loader.hide();
                        vm.states = response.data
                    })
                    .catch(function (error) {
                        loader.hide();
                        vm.errors = error.response.data.errors;
                        vm.$store.dispatch("error", error.response.data.message);
                    });
            },

            getStateNotices() {
                let vm = this;
                let loader = vm.$loading.show();
                vm.$store
                    .dispatch("post", { uri: "getStateNotices", data:{ meta:{region_id:1}} })
                    .then((response) => {
                        loader.hide();
                        vm.notices = response.data
                        vm.getCategories()
                    })
                    .catch(function (error) {
                        loader.hide();
                        vm.errors = error.response.data.errors;
                        vm.$store.dispatch("error", error.response.data.message);
                    });
            },

            getCategories() {
                let vm = this;
                let loader = vm.$loading.show();
                vm.$store
                    .dispatch("post", { uri: "getCategories" })
                    .then((response) => {
                        loader.hide();
                        vm.categories = response.data
                        vm.getStateAgencies()
                    })
                    .catch(function (error) {
                        loader.hide();
                        vm.errors = error.response.data.errors;
                        vm.$store.dispatch("error", error.response.data.message);
                    });
            },

            getStateAgencies() {
                let vm = this;
                vm.$store
                    .dispatch("post", { uri: "getStateAgencies" })
                    .then((response) => {
                        vm.agencies = response.data
                    })
                    .catch(function (error) {
                        console.log(error)
                    });
            },
        },
    };
</script>
<style scoped>
    .margin_top{   
        margin-top: 20px;
    }
</style>