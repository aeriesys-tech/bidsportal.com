<template>
       <div class="main-footer">
        <span>&copy; 2024. <a href="#">Bidsportal</a>. All Rights Reserved.</span>
        <span>Created by: <a href="" target="_blank">Bidsportal</a></span>
      </div><!-- main-footer -->
</template>